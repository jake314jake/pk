<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$plugins['datatables'] = [
  'css' => [
    'assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css',
    'assets/dist/css/custom.datatables.css',
  ],
  'js' => [
    'assets/plugins/datatables/jquery.dataTables.min.js',
    'assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js',
    'assets/dist/js/dtutils.js'
  ]
];

$plugins['datatables-buttons'] = [
  'css' => [
    'assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css'
  ],
  'js' => [
    'assets/plugins/datatables-buttons/js/dataTables.buttons.min.js',
    'assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js',
    'assets/plugins/datatables-buttons/js/buttons.colVis.min.js',
    'assets/plugins/datatables-buttons/js/buttons.flash.min.js',
    'assets/plugins/datatables-buttons/js/buttons.html5.min.js',
    'assets/plugins/datatables-buttons/js/buttons.print.min.js',
  ]
];

$plugins['datatables-colreorder'] = [
  'css' => [
    'assets/plugins/datatables-colreorder/css/colReorder.bootstrap4.min.css'
  ],
  'js' => [
    'assets/plugins/datatables-buttons/js/dataTables.colReorder.min.js',
    'assets/plugins/datatables-buttons/js/colReorder.bootstrap4.min.js'
  ]
];

$plugins['jstree'] = [
  'css' => [
    'assets/plugins/jstree/jstree.bundle.css'
  ],
  'js' => [
    'assets/plugins/jstree/jstree.bundle.js'
  ]
];

$plugins['validation'] = [
  'css' => [],
  'js' => [
    'assets/plugins/jquery-validation/jquery.validate.min.js',
    'assets/plugins/jquery-validation/additional-methods.min.js',
  ]
];

$plugins['select2'] = [
  'css' => [
    'assets/plugins/select2/css/select2.min.css',
    'assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css',
  ],
  'js' => [
    'assets/plugins/select2/js/select2.min.js',
  ]
];

$config['plugins'] = $plugins;