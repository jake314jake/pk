<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Person_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
    }

    // Get all persons
    public function get_all()
    {
        $query = $this->db->query("SELECT * FROM person ORDER BY id DESC");
        return $query->result_array();
    }

    // Get person by ID
    public function get_by_id($id)
    {
        $query = $this->db->query("SELECT * FROM person WHERE id = ?", array($id));
        return $query->row_array();
    }

    // Insert new person
    public function insert($data)
    {
        $sql = "INSERT INTO person (first_name, last_name, email, phone) VALUES (?, ?, ?, ?)";
        return $this->db->query($sql, array(
            $data['first_name'],
            $data['last_name'],
            $data['email'],
            isset($data['phone']) ? $data['phone'] : null
        ));
    }

    // Update person
    public function update($id, $data)
    {
        $sql = "UPDATE person SET first_name = ?, last_name = ?, email = ?, phone = ? WHERE id = ?";
        return $this->db->query($sql, array(
            $data['first_name'],
            $data['last_name'],
            $data['email'],
            isset($data['phone']) ? $data['phone'] : null,
            $id
        ));
    }

    // Delete person
    public function delete($id)
    {
        $sql = "DELETE FROM person WHERE id = ?";
        return $this->db->query($sql, array($id));
    }
}