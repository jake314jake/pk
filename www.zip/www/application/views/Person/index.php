<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="content">


    <!-- Main content -->
    <section class="content">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <!-- Outer Card -->
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h3 class="card-title"><i class="fa fa-users"></i> Person List</h3>
                        <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#addPersonModal">
                            <i class="fa fa-plus"></i> Add Person
                        </button>
                    </div>
                    <div class="card-body bg-white">
                        <!-- Inner Card for Table -->
                        <div class="card">
                            <div class="card-body table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>#</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Created At</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($persons as $person): ?>
                                        <tr>
                                            <td><?= $person['id'] ?></td>
                                            <td><?= htmlspecialchars($person['first_name']) ?></td>
                                            <td><?= htmlspecialchars($person['last_name']) ?></td>
                                            <td><?= htmlspecialchars($person['email']) ?></td>
                                            <td><?= htmlspecialchars($person['phone']) ?></td>
                                            <td><?= date('d M Y H:i', strtotime($person['created_at'])) ?></td>
                                            <td>
                                                <!-- View button -->
                                                <a href="<?= base_url('person/view/'.$person['id']) ?>" class="btn btn-primary btn-sm" title="View">
                                                    <i class="fa fa-eye"></i>
                                                </a>

                                                <!-- Edit button -->
                                                <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#editPersonModal<?= $person['id'] ?>" title="Edit">
                                                    <i class="fa fa-edit"></i>
                                                </button>

                                                <!-- Delete button -->
                                                <a href="<?= base_url('person/delete/'.$person['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')" title="Delete">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>

                                        <!-- Edit Modal -->
                                        <div class="modal fade" id="editPersonModal<?= $person['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="editPersonLabel<?= $person['id'] ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <form method="post" action="<?= base_url('person/edit/'.$person['id']) ?>">
                                                        <div class="modal-header bg-info text-white">
                                                            <h5 class="modal-title" id="editPersonLabel<?= $person['id'] ?>"><i class="fa fa-edit"></i> Edit Person</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true" class="text-white">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="form-group">
                                                                <label>First Name</label>
                                                                <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($person['first_name']) ?>" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Last Name</label>
                                                                <input type="text" name="last_name" class="form-control" value="<?= htmlspecialchars($person['last_name']) ?>" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Email</label>
                                                                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($person['email']) ?>" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Phone</label>
                                                                <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($person['phone']) ?>">
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-info">Save Changes</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div> <!-- End Inner Card -->
                    </div>
                </div> <!-- End Outer Card -->
            </div>
        </div>

    </section>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addPersonModal" tabindex="-1" role="dialog" aria-labelledby="addPersonLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="post" action="<?= base_url('person/create') ?>">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="addPersonLabel"><i class="fa fa-plus"></i> Add New Person</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true" class="text-white">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="first_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="last_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Add Person</button>
                </div>
            </form>
        </div>
    </div>
</div>