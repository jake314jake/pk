<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="content">
    <!-- Content Header -->
    <section class="content-header">
        <h1>
            View Person
            <small>Details</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url() ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?= base_url('Person') ?>">Person</a></li>
            <li class="active">View</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fa fa-user"></i> <?= htmlspecialchars($person['first_name'] . ' ' . $person['last_name']) ?></h3>
                        <div class="card-tools">
                            <a href="<?= base_url('Person/edit/'.$person['id']) ?>" class="btn btn-info btn-sm">
                                <i class="fa fa-edit"></i> Edit
                            </a>
                            <a href="<?= base_url('Person/Person') ?>" class="btn btn-secondary btn-sm">
                                <i class="fa fa-arrow-left"></i> Back
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-sm-4 font-weight-bold">First Name:</div>
                            <div class="col-sm-8"><?= htmlspecialchars($person['first_name']) ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-sm-4 font-weight-bold">Last Name:</div>
                            <div class="col-sm-8"><?= htmlspecialchars($person['last_name']) ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-sm-4 font-weight-bold">Email:</div>
                            <div class="col-sm-8"><?= htmlspecialchars($person['email']) ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-sm-4 font-weight-bold">Phone:</div>
                            <div class="col-sm-8"><?= htmlspecialchars($person['phone']) ?: '-' ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-sm-4 font-weight-bold">Created At:</div>
                            <div class="col-sm-8"><?= date('d M Y H:i', strtotime($person['created_at'])) ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-sm-4 font-weight-bold">Updated At:</div>
                            <div class="col-sm-8"><?= date('d M Y H:i', strtotime($person['updated_at'])) ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
</div>