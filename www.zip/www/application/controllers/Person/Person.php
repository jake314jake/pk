<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Person extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Person/Person_model'); // load the model
    }

    // List all persons
    public function index()
    {
        $data['persons'] = $this->Person_model->get_all(); // get all persons
        $this->template
            ->page_title('Person Management')
            ->load('person/index', $data); // load view and pass data
    }

    // Show single person (optional)
    public function view($id)
    {
        $data['person'] = $this->Person_model->get_by_id($id);
        $this->template
            ->page_title('View Person')
            ->load('person/view', $data);
    }

    // Add person
    public function create()
    {
        if($this->input->post())
        {
            $person_data = array(
                'first_name' => $this->input->post('first_name'),
                'last_name'  => $this->input->post('last_name'),
                'email'      => $this->input->post('email'),
                'phone'      => $this->input->post('phone'),
            );

            $this->Person_model->insert($person_data);
            redirect('person'); // redirect to list
        }

        $this->template
            ->page_title('Add New Person')
            ->load('person/create');
    }

    // Edit person
    public function edit($id)
    {
        $data['person'] = $this->Person_model->get_by_id($id);

        if($this->input->post())
        {
            $person_data = array(
                'first_name' => $this->input->post('first_name'),
                'last_name'  => $this->input->post('last_name'),
                'email'      => $this->input->post('email'),
                'phone'      => $this->input->post('phone'),
            );

            $this->Person_model->update($id, $person_data);
            redirect('person');
        }

        $this->template
            ->page_title('Edit Person')
            ->load('person/edit', $data);
    }

    // Delete person
    public function delete($id)
    {
        $this->Person_model->delete($id);
        redirect('person');
    }
}